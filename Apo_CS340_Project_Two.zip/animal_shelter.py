#!/usr/bin/env python
# coding: utf-8

# In[1]:


from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        # Connection variables
        USER = 'aacuser'
        PASS = 'securePassw0rd2'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32435
        DB = 'AAC'
        COL = 'animals'
        # Initialize Connection
        from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        # Connection variables
        USER = 'aacuser'
        PASS = 'securePassw0rd2'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32435
        DB = 'AAC'
        COL = 'animals'
        # Initialize Connection
        from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password):
        # Connection variables
        USER = 'aacuser'
        PASS = 'securePassw0rd2'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 32435
        DB = 'AAC'
        COL = 'animals'
        # Initialize Connection
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (USER,PASS,HOST,PORT))
        self.database = self.client[DB]
        self.collection = self.database[COL]
        
# Complete this create method to implement the C in CRUD
    def create(self, data):
        if data is not None:
            try:
                insertion_result = self.collection.insert_one(data) # Data should be a dictionary
                return insertion_result.acknowledged
            except Exception as e:
                print(f"An error has occured: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty.")
    
# Create method to implement the R in CRUD
    def read(self, query):
        if query is not None:
            try:
                cursor = self.collection.find(query)
                return cursor
            except Exception as e:
                print(f"An error has occured: {e}")
                return None
        else:
            raise Exception("Query parameter is empty.")

# Create method to implement the U in CRUD
    def update(self, query,update_data):
        if query is not None and update_data is not None:
            try:
                update_result = self.collection.update_many(query, {'$set': update_data})
                # Return count of modified documents
                return update_result.modified_count
            except Exception as e:
                print(f"An error has occured: {e}")
                return 0
        else:
            raise Exception("Query and update data parameters, cannot be empty.")

# Create method to implement the D in CRUD
    def delete(self, query):
        if query is not None:
            try:
                delete_result = self.collection.delete_many(query)
                # Return count of deleted documents
                return delete_result.deleted_count
            except Exception as e:
                print(f"An error has occured: {e}")
                return 0
        else:
            raise Exception("Query parameter is empty.")
        self.database = self.client[DB]
        self.collection = self.database[COL]
        
# Complete this create method to implement the C in CRUD
    def create(self, data):
        if data is not None:
            try:
                insertion_result = self.collection.insert_one(data) # Data should be a dictionary
                return insertion_result.acknowledged
            except Exception as e:
                print(f"An error has occured: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty.")
    
# Create method to implement the R in CRUD
    def read(self, query):
        if query is not None:
            try:
                cursor = self.collection.find(query)
                return cursor
            except Exception as e:
                print(f"An error has occured: {e}")
                return None
        else:
            raise Exception("Query parameter is empty.")

# Create method to implement the U in CRUD
    def update(self, query,update_data):
        if query is not None and update_data is not None:
            try:
                update_result = self.collection.update_many(query, {'$set': update_data})
                # Return count of modified documents
                return update_result.modified_count
            except Exception as e:
                print(f"An error has occured: {e}")
                return 0
        else:
            raise Exception("Query and update data parameters, cannot be empty.")

# Create method to implement the D in CRUD
    def delete(self, query):
        if query is not None:
            try:
                delete_result = self.collection.delete_many(query)
                # Return count of deleted documents
                return delete_result.deleted_count
            except Exception as e:
                print(f"An error has occured: {e}")
                return 0
        else:
            raise Exception("Query parameter is empty.")
        self.database = self.client[DB]
        self.collection = self.database[COL]
        
# Complete this create method to implement the C in CRUD
    def create(self, data):
        if data is not None:
            try:
                insertion_result = self.collection.insert_one(data) # Data should be a dictionary
                return insertion_result.acknowledged
            except Exception as e:
                print(f"An error has occured: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty.")
    
# Create method to implement the R in CRUD
    def read(self, query):
        if query is not None:
            try:
                cursor = self.collection.find(query)
                return cursor
            except Exception as e:
                print(f"An error has occured: {e}")
                return None
        else:
            raise Exception("Query parameter is empty.")

# Create method to implement the U in CRUD
    def update(self, query,update_data):
        if query is not None and update_data is not None:
            try:
                update_result = self.collection.update_many(query, {'$set': update_data})
                # Return count of modified documents
                return update_result.modified_count
            except Exception as e:
                print(f"An error has occured: {e}")
                return 0
        else:
            raise Exception("Query and update data parameters, cannot be empty.")

# Create method to implement the D in CRUD
    def delete(self, query):
        if query is not None:
            try:
                delete_result = self.collection.delete_many(query)
                # Return count of deleted documents
                return delete_result.deleted_count
            except Exception as e:
                print(f"An error has occured: {e}")
                return 0
        else:
            raise Exception("Query parameter is empty.")


# In[ ]:




